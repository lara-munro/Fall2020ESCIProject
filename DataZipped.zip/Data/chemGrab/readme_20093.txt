###################################
########### Disclaimer ############
This is the most recent readme publication based on all site-date combinations used during stackByTable.
Information specific to the query, including sites and dates, has been removed. The remaining content reflects general metadata for the data product.
##################################

This data package been produced by and downloaded from the National Ecological Observatory Network (NEON). NEON is funded by the National Science Foundation (Awards 0653461, 0752017, 1029808, 1138160, 1246537, 1638695, 1638696, 1724433) and managed cooperatively by Battelle. These data are provided under the terms of the NEON data policy at https://www.neonscience.org/data-policy.
DATA PRODUCT INFORMATION
------------------------
ID: NEON.DOM.SITE.DP1.20093.001
Name: Chemical properties of surface water
Description: Grab samples of surface water chemistry including general chemistry, anions, cations, and nutrients.
NEON Science Team Supplier: Aquatic Observation System
Abstract: This data product contains the quality-controlled, native sampling resolution data from NEON's surface water chemistry sampling protocol. Subsamples are analyzed at NEON domain headquarters for alkalinity and acid neutralizing capacity (ANC); other subsamples are sent to external facilities for a broad suite of analytes, including dissolved and total nutrients and carbon, cations and anions, and general chemistry. For additional details, see the user guide, protocols, and science design listed in the Documentation section in this data product's details webpage.
Latency:
The expected time from data and/or sample collection in the field to data publication is as follows, for each of the data tables (in days) in the downloaded data package. See the Data Product User Guide for more information.
swc_domainLabData:  60
swc_externalLabData:  150
swc_fieldData:  30
swc_fieldSuperParent:  30
swc_externalLabSummaryData:  14
Brief Design Description: Grab samples of surface water at NEON aquatic sites are collected in streams and rivers 15- 26 times per year and 12 times per year in lakes. In streams and rivers, 12 samples are collected at regular intervals during the sampling season while the remaining 14 are collected on an irregular basis to capture major flow events. In lakes samples are collected approximately monthly and to capture ice-on and ice-off events. The field protocol used by NEON for collecting surface water chemistry samples follows the general requirements set forth by the 2011 USGS National Water-Quality Assessment (NAWQA) Program and the Arctic LTER standard operating procedures (SOP). Sample handling and preparation portions of this protocol follow the general requirements set forth by the USGS National Water-Quality Assessment (NAWQA) Program (USGS 2006).
Brief Study Area Description: Measured at all NEON aquatic sites.
Sensor(s): 
Keywords: nitrogen (N), total carbon (TC), phosphorous (P), analytes, surface water, acid neutralizing capacity (ANC), carbon (C), alkalinity, cations, grab samples, water quality, chemistry, anions, nutrients, chemical properties
Domain: D12
DATA PACKAGE CONTENTS
---------------------
This folder contains the following documentation files:
This data product contains up to 6 data tables:
- Term descriptions, data types, and units: NEON.D12.BLDE.DP1.20093.001.variables.20211129T154501Z.csv
swc_fieldSuperParent - Field data for the parent sample of surface water chemistry
swc_domainLabData - Surface water chemistry ALK and ANC domain lab data summary data
swc_externalLabSummaryData - Surface water chemistry external lab summary data
swc_externalLabData - Surface water chemistry from external lab
swc_fieldData - Surface water chemistry summary data per site per bout
swc_externalLabDataByAnalyte - Surface water chemistry from external lab in long format
Expanded download package definition: The expanded package for this data product contain metadata associated with the in-house alkalinity and ANC titrations, and method detection limits from the analytical laboratory.
FILE NAMING CONVENTIONS
-----------------------
NEON data files are named using a series of component abbreviations separated by periods. File naming conventions for NEON data files differ between NEON science teams. A file will have the same name whether it is accessed via NEON's data portal or API. Please visit https://www.neonscience.org/data-formats-conventions for a full description of the naming conventions.
ISSUE LOG
----------
This log provides a list of issues that were identified during data collection or processing, prior to publication of this data package. For a more recent log, please visit this data product's detail page at https://data.neonscience.org/data-products/DP1.20093.001.
Issue Date: 2021-01-06
Issue: Safety measures to protect personnel during the COVID-19 pandemic resulted in reduced or eliminated sampling activities for extended periods at NEON sites. Data availability may be reduced during this time.
       Date Range: 2020-03-23 to 2021-06-01
       Location(s) Affected: All
Resolution Date: 
Resolution: 
Issue Date: 2020-09-10
Issue: External lab data for surface water and groundwater chemistry has been transformed from wide format to long format. The wide format table (`swc_externalLabData`) has been deprecated, and replaced with this table: `swc_externalLabDataByAnalyte`.
       Date Range: 2020-04-01 to 2020-09-10
       Location(s) Affected: All aquatic sites
Resolution Date: 2020-04-01
Resolution: All previous data has been transferred to the table
Issue Date: 2020-10-28
Issue: ANC samples only taken monthly
       Date Range: 2012-01-01 to 2018-01-01
       Location(s) Affected: All Aquatic Sites
Resolution Date: 2018-01-01
Resolution: Field sampling discontinued at seepage lake inlet and outlet locations
Issue Date: 2020-10-28
Issue: Field sampling discontinued at seepage lake inlet and outlet locations
       Date Range: 2012-01-01 to 2018-01-01
       Location(s) Affected: BARC, SUGG, CRAM, LIRO, PRLA, PRPO
Resolution Date: 2018-01-01
Resolution: Field sampling discontinued at seepage lake inlet and outlet locations New change log entry for surface water chemistry data products.
ADDITIONAL INFORMATION
----------------------
The protocol dictates that each siteID x stationID combination is sampled at least once per event (one record expected per parentSampleID in `swc_fieldSuperParent`).  A record from `swc_fieldSuperParent` may have zero to three child records in `swc_fieldData`, depending on whether a water sample was collected. In the event that a water sample cannot be taken, a record will still be created in `swc_fieldSuperParent`, and `swc_fieldSuperParent.samplingImpractical` will be something other than NULL, but there will be no corresponding record in `swc_fieldData`. Periodically, triplicate water samples are collected and three child records in `swc_fieldData` are expected for a single record in `swc_fieldSuperParent` Each record from `swc_fieldData` is expected to have at least one child record in `swc_domainLabData` (one for ALK and ANC, if sampled). Three times per year, duplicate ALK samples are analyzed and two ALK child records in `swc_domainLabData` are expected for a single record in `swc_fieldData`. Each record from `swc_fieldData` is also expected to have up to 33 child records in `swc_externalLabDataByAnalyte`, one per analyte. However, duplicates and/or missing data may exist where protocol and/or data entry aberrations have occurred; Users should check data carefully for anomalies before joining tables.
NEON DATA POLICY AND CITATION GUIDELINES
----------------------------------------
A citation statement is available in this data product's detail page at https://data.neonscience.org/data-products/DP1.20093.001. Please visit https://www.neonscience.org/data-policy for more information about NEON's data policy and citation guidelines.
DATA QUALITY AND VERSIONING
---------------------------
NEON data are initially published with a status of Provisional, in which updates to data and/or processing algorithms will occur on an as-needed basis, and query reproducibility cannot be guaranteed. Once data are published as part of a Data Release, they are no longer provisional, and are associated with a stable DOI. 
To learn more about provisional versus released data, please visit https://www.neonscience.org/data-revisions-releases.
