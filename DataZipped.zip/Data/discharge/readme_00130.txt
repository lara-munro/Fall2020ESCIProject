###################################
########### Disclaimer ############
This is the most recent readme publication based on all site-date combinations used during stackByTable.
Information specific to the query, including sites and dates, has been removed. The remaining content reflects general metadata for the data product.
##################################

This data package been produced by and downloaded from the National Ecological Observatory Network (NEON). NEON is funded by the National Science Foundation (Awards 0653461, 0752017, 1029808, 1138160, 1246537, 1638695, 1638696, 1724433) and managed cooperatively by Battelle. These data are provided under the terms of the NEON data policy at https://www.neonscience.org/data-policy.
DATA PRODUCT INFORMATION
------------------------
ID: NEON.DOM.SITE.DP4.00130.001
Name: Continuous discharge
Description: Continuous measurements of stream discharge calculated from a stage-discharge rating curve and sensor-based measurements of water surface elevation.
NEON Science Team Supplier: Aquatic Instrument System
Abstract: This data product describes the volume of water flowing through a stream or river cross-section during a given period of time. For each NEON stream or river site, site-specific stage-discharge rating curve equations are derived from point observations of gauge height and discharge. Continuous sensor measurements of surface water pressure are used to derive water column height. The rating curve equations are applied to water column height to derive continuous stream discharge.
Latency:
Data collected in any given month are published during the second full week of the following month.
Brief Design Description: NEON calculates continuous stream discharge in all rivers and wadeable stream sites within the Observatory. Stream discharge data are calculated using pressure of surface water L0 data (DP0.20016; the raw, level 0 inputs used to calculate Elevation of surface water, DP1.20016), stream discharge rating curve data (DP4.00133), gauge height data (DP1.20267.001) and geolocation information. Continuous discharge data are reported once per minute.
Brief Study Area Description: This data product is measured at NEON aquatic wadeable stream and river sites.
Sensor(s): Level TROLL 500
Keywords: streams, rivers, gage height, stream discharge, gage, stage, streamgage, streamflow, aquatic, rating curve, gage depth
Domain: D12
DATA PACKAGE CONTENTS
---------------------
This folder contains the following documentation files:
This data product contains up to 4 data tables:
- Term descriptions, data types, and units: NEON.D12.BLDE.DP4.00130.001.variables.20211105T195104Z.csv
sdrc_gaugePressureRelationship - Information relating staff gauge readings to pressure measurements
csd_continuousDischarge - Continuous discharge data calculated from in situ pressure and stage-discharge rating curve
geo_gaugeWaterColumnRegression - Statistics and information on gauge height vs. water column height regressions used in estimating continuous discharge
bat_gaugeWaterColumnRegression - Statistics and information on gauge height vs. water column height regressions used in estimating continuous discharge
Expanded download package definition: The expanded package includes additional details about quality flagging and information related to the relationship between pressure measurements and periodic staff gauge readings.
FILE NAMING CONVENTIONS
-----------------------
NEON data files are named using a series of component abbreviations separated by periods. File naming conventions for NEON data files differ between NEON science teams. A file will have the same name whether it is accessed via NEON's data portal or API. Please visit https://www.neonscience.org/data-formats-conventions for a full description of the naming conventions.
ISSUE LOG
----------
This log provides a list of issues that were identified during data collection or processing, prior to publication of this data package. For a more recent log, please visit this data product's detail page at https://data.neonscience.org/data-products/DP4.00130.001.
Issue Date: 2021-06-16
Issue: Change in location of gage causes shift in equivalent stage.
       Date Range: 2019-04-09 to 2019-04-11
       Location(s) Affected: SYCA
       Date Range: 2019-06-05 to 2019-06-07
       Location(s) Affected: SYCA
Resolution Date: 2021-06-16
Resolution: Shift flagged.
Issue Date: 2021-05-26
Issue: Poor troll to gage regression.
       Date Range: 2017-04-03 to 2017-05-31
       Location(s) Affected: LECO
Resolution Date: 2021-05-26
Resolution: 
Issue Date: 2021-05-25
Issue: Dry stream or discontinuous pools created by extreme low discharge.
       Date Range: 2017-10-01 to 2018-09-30
       Location(s) Affected: MCDI
Resolution Date: 2021-05-25
Resolution: Data flagged.
Issue Date: 2021-02-03
Issue: Movement of pressure transducer, impacting continuous discharge estimates.
       Date Range: 2017-04-05 to 2017-07-14
       Location(s) Affected: KING
       Date Range: 2017-06-20 to 2017-06-21
       Location(s) Affected: LECO
       Date Range: 2017-08-15 to 2017-08-16
       Location(s) Affected: HOPB
       Date Range: 2017-09-05 to 2017-10-01
       Location(s) Affected: KING
       Date Range: 2017-09-11 to 2017-09-12
       Location(s) Affected: HOPB
       Date Range: 2017-10-26 to 2017-11-01
       Location(s) Affected: LECO
       Date Range: 2017-11-19 to 2017-11-20
       Location(s) Affected: HOPB
       Date Range: 2018-02-20 to 2018-02-27
       Location(s) Affected: PRIN
       Date Range: 2018-03-13 to 2018-03-14
       Location(s) Affected: LECO
       Date Range: 2018-05-29 to 2018-06-03
       Location(s) Affected: WALK
       Date Range: 2018-06-05 to 2018-06-06
       Location(s) Affected: MART
       Date Range: 2018-06-16 to 2018-06-17
       Location(s) Affected: REDB
       Date Range: 2018-06-17 to 2018-06-18
       Location(s) Affected: CUPE
       Date Range: 2018-06-19 to 2018-06-19
       Location(s) Affected: REDB
       Date Range: 2018-06-19 to 2018-06-20
       Location(s) Affected: LECO
       Date Range: 2018-06-25 to 2018-06-26
       Location(s) Affected: GUIL
       Date Range: 2018-06-26 to 2018-06-28
       Location(s) Affected: REDB
       Date Range: 2018-06-27 to 2018-06-27
       Location(s) Affected: REDB
       Date Range: 2018-06-29 to 2018-06-29
       Location(s) Affected: REDB
       Date Range: 2018-07-01 to 2018-07-02
       Location(s) Affected: CUPE
       Date Range: 2018-07-05 to 2018-07-06
       Location(s) Affected: GUIL
       Date Range: 2018-07-09 to 2018-07-09
       Location(s) Affected: REDB
       Date Range: 2018-07-12 to 2018-07-13
       Location(s) Affected: BIGC
       Date Range: 2018-07-22 to 2018-07-24
       Location(s) Affected: MART
       Date Range: 2018-07-24 to 2018-07-24
       Location(s) Affected: REDB
       Date Range: 2018-07-24 to 2018-07-25
       Location(s) Affected: PRIN
       Date Range: 2018-07-25 to 2018-07-26
       Location(s) Affected: CUPE
       Date Range: 2018-08-09 to 2018-08-09
       Location(s) Affected: REDB
       Date Range: 2018-08-20 to 2018-08-21
       Location(s) Affected: OKSR
       Date Range: 2018-09-01 to 2018-09-01
       Location(s) Affected: OKSR
       Date Range: 2018-09-06 to 2018-09-06
       Location(s) Affected: REDB
       Date Range: 2018-09-20 to 2018-09-20
       Location(s) Affected: REDB
       Date Range: 2018-10-09 to 2018-10-10
       Location(s) Affected: BIGC
       Date Range: 2018-11-14 to 2018-11-15
       Location(s) Affected: PRIN
       Date Range: 2018-11-26 to 2018-11-28
       Location(s) Affected: GUIL
       Date Range: 2018-11-28 to 2018-11-30
       Location(s) Affected: PRIN
       Date Range: 2018-12-10 to 2018-12-11
       Location(s) Affected: GUIL
       Date Range: 2018-12-19 to 2019-07-28
       Location(s) Affected: ARIK
       Date Range: 2019-01-01 to 2019-01-02
       Location(s) Affected: BIGC
       Date Range: 2019-01-28 to 2019-01-29
       Location(s) Affected: BIGC
       Date Range: 2019-01-29 to 2019-01-30
       Location(s) Affected: CUPE
       Date Range: 2019-02-19 to 2019-02-20
       Location(s) Affected: GUIL
       Date Range: 2019-02-26 to 2019-02-27
       Location(s) Affected: CUPE
       Date Range: 2019-04-03 to 2019-07-01
       Location(s) Affected: LEWI
       Date Range: 2019-04-09 to 2019-04-11
       Location(s) Affected: MCDI
       Date Range: 2019-05-05 to 2019-05-06
       Location(s) Affected: BIGC
       Date Range: 2019-06-10 to 2019-06-11
       Location(s) Affected: GUIL
       Date Range: 2019-07-26 to 2019-08-19
       Location(s) Affected: REDB
       Date Range: 2019-08-21 to 2019-08-23
       Location(s) Affected: LECO
       Date Range: 2019-09-03 to 2019-09-11
       Location(s) Affected: BLUE
Resolution Date: 2021-02-26
Resolution: Affected data flagged. Pressure transducer secured.
Issue Date: 2020-12-10
Issue: Ice pressure affecting pressure measurements, impacting continuous discharge estimates.
       Date Range: 2017-11-08 to 2018-04-04
       Location(s) Affected: WLOU
       Date Range: 2017-12-12 to 2018-01-19
       Location(s) Affected: HOPB
       Date Range: 2017-12-12 to 2018-02-03
       Location(s) Affected: COMO
       Date Range: 2017-12-27 to 2018-01-05
       Location(s) Affected: POSE
       Date Range: 2018-04-27 to 2018-04-30
       Location(s) Affected: COMO
       Date Range: 2019-01-11 to 2019-03-14
       Location(s) Affected: HOPB
       Date Range: 2019-10-09 to 2019-10-15
       Location(s) Affected: BLDE
       Date Range: 2019-10-28 to 2019-11-05
       Location(s) Affected: BLDE
       Date Range: 2019-11-21 to 2019-12-01
       Location(s) Affected: BLDE
       Date Range: 2020-01-25 to 2020-01-29
       Location(s) Affected: POSE
       Date Range: 2020-02-06 to 2020-02-10
       Location(s) Affected: POSE
       Date Range: 2020-04-09 to 2020-04-19
       Location(s) Affected: BLDE
Resolution Date: 2021-02-18
Resolution: Affected data flagged.
Issue Date: 2021-01-19
Issue: Stage outside range of rating curve.
       Date Range: 2016-07-30 to 2016-07-31
       Location(s) Affected: POSE
       Date Range: 2016-08-17 to 2016-08-18
       Location(s) Affected: POSE
       Date Range: 2017-05-05 to 2017-05-06
       Location(s) Affected: POSE
       Date Range: 2017-06-22 to 2017-06-26
       Location(s) Affected: MAYF
       Date Range: 2017-10-30 to 2017-10-30
       Location(s) Affected: HOPB
       Date Range: 2018-06-03 to 2018-06-03
       Location(s) Affected: POSE
       Date Range: 2018-12-28 to 2018-12-30
       Location(s) Affected: MAYF
       Date Range: 2019-01-17 to 2019-01-18
       Location(s) Affected: BIGC
       Date Range: 2019-02-02 to 2019-02-05
       Location(s) Affected: BIGC
       Date Range: 2019-02-13 to 2019-02-14
       Location(s) Affected: TECR
       Date Range: 2019-02-13 to 2019-02-16
       Location(s) Affected: BIGC
       Date Range: 2019-03-02 to 2019-03-11
       Location(s) Affected: BIGC
       Date Range: 2019-05-02 to 2019-05-02
       Location(s) Affected: PRIN
       Date Range: 2019-08-30 to 2019-09-01
       Location(s) Affected: KING
Resolution Date: 2021-02-03
Resolution: Affected data flagged. Rating curves may be revised to include future higher measured flows.
ADDITIONAL INFORMATION
----------------------
Queries for this product will return data for all dates within the specified date range. Continuous stream discharge data are provided at one-minute intervals. Preliminary data for continuous discharge are calculated using the rating curve from the preceding water year (October 1 - September 31), while the annual versions are re-calculated following the end of the water year in which the pressure data was recorded, using the most recent rating curve. The data package includes unique identifiers for the curve fit to stage-discharge rating curves, uncertainty values at the 95% confidence intervals, and data quality flags associated with individual discharge values.
NEON DATA POLICY AND CITATION GUIDELINES
----------------------------------------
A citation statement is available in this data product's detail page at https://data.neonscience.org/data-products/DP4.00130.001. Please visit https://www.neonscience.org/data-policy for more information about NEON's data policy and citation guidelines.
DATA QUALITY AND VERSIONING
---------------------------
NEON data are initially published with a status of Provisional, in which updates to data and/or processing algorithms will occur on an as-needed basis, and query reproducibility cannot be guaranteed. Once data are published as part of a Data Release, they are no longer provisional, and are associated with a stable DOI. 
To learn more about provisional versus released data, please visit https://www.neonscience.org/data-revisions-releases.
