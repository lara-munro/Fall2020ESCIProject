###################################
########### Disclaimer ############
This is the most recent readme publication based on all site-date combinations used during stackByTable.
Information specific to the query, including sites and dates, has been removed. The remaining content reflects general metadata for the data product.
##################################

This data package been produced by and downloaded from the National Ecological Observatory Network (NEON). NEON is funded by the National Science Foundation (Awards 0653461, 0752017, 1029808, 1138160, 1246537, 1638695, 1638696, 1724433) and managed cooperatively by Battelle. These data are provided under the terms of the NEON data policy at https://www.neonscience.org/data-policy.
DATA PRODUCT INFORMATION
------------------------
ID: NEON.DOM.SITE.DP1.20033.001
Name: Nitrate in surface water
Description: In situ sensor-based nitrate concentration, available as fifteen minute  averages in surface water in lakes, wadeable and non-wadeable streams
NEON Science Team Supplier: Aquatic Instrument System
Abstract: Nitrate is measured using an optical sensor at the downstream (S2) sensor station in streams and on the buoy at lake and river sites. It is reported as a mean value from 20 measurements made during a sampling burst every 15 minutes. Some older data may have been processed as the mean value from 50 measurements, but as of late 2018, the algorithm was updated to 20 measurements and older data will eventually be re-processed to use 20 measurements.
Latency:
Data collected in any given month are published during the second full week of the following month.
Brief Design Description: The stream sensor stations measure PAR at water surface, water level, temperature, water quality, and at downstream stations, nitrate. The buoys are comprised of sensor sets which measure meteorological parameters over a water surface along with submerged sensors that measure physical and chemical parameters of the water. Some of these sensors are unique to the buoy subsystem and others are shared with other NEON subsystems, such as the wadeable stream sensor sets or terrestrial towers. Due to power, space, and data storage constraints on the buoy, the configuration of sensors deployed on a buoy may be different than those in other parts of NEON.
Brief Study Area Description: Upstream (S1) and downstream (S2) sensor stations are at all stream sites within NEON. Buoys (S1) will be deployed as a single station at all lake and large river (non-wadeable) sites within NEON.
Sensor(s): Seabird - SUNA V2 UV nitrate sensor
Keywords: rivers, streams, lakes, surface water chemistry, water quality, nitrogen (N), nutrients, nitrate (NO3-), buoy, surface water
Domain: D12
DATA PACKAGE CONTENTS
---------------------
This folder contains the following documentation files:
This data product contains up to 3 data tables:
- Term descriptions, data types, and units: NEON.D12.BLDE.DP1.20033.001.variables.20211105T192952Z.csv
ais_maintenance - Information related to aquatic sensor and infrastructure maintenance
ais_sunaCleanAndCal - Record of SUNA cleaning and calibration activities
NSW_15_minute - Nitrate in surface water summarized over 2 minutes from burst measurements taken every 15 minutes
If data are unavailable for the particular sites and dates queried, some tables may be absent.
Basic download package definition: Includes the data product, summary statistics, expanded uncertainty, and final quality flag.
Expanded download package definition: Includes the basic package information plus quality metrics for all of the quality assessment and quality control analyses.
FILE NAMING CONVENTIONS
-----------------------
NEON data files are named using a series of component abbreviations separated by periods. File naming conventions for NEON data files differ between NEON science teams. A file will have the same name whether it is accessed via NEON's data portal or API. Please visit https://www.neonscience.org/data-formats-conventions for a full description of the naming conventions.
ISSUE LOG
----------
This log provides a list of issues that were identified during data collection or processing, prior to publication of this data package. For a more recent log, please visit this data product's detail page at https://data.neonscience.org/data-products/DP1.20033.001.
Issue Date: 2020-11-03
Issue: Low flow conditions resulting in exposed sensors
       Date Range: 2020-10-06 to 2021-04-18
       Location(s) Affected: KING (HOR.VER: 101.100; 102.100)
       Date Range: 2020-10-19 to 2021-04-30
       Location(s) Affected: SYCA (HOR.VER: 101.100; 102.100)
       Date Range: 2021-07-23 to 2021-09-02
       Location(s) Affected: MCRA
Resolution Date: 
Resolution: Ongoing dry conditions
Issue Date: 2021-01-14
Issue: Safety measures to protect personnel during the COVID-19 pandemic resulted in reduced or eliminated maintenance activities for extended periods at NEON sites. Data availability and/or quality may be negatively impacted during this time, and extra scrutiny of data is advised.
The annual refresh of sensors and data acquisition systems (DAS) also did not occur according to the typical 1-year schedule for many sites. The annual refresh is where freshly calibrated and verified sensors and DAS replace the units that have been deployed for a year. While NEON is working towards implementing automated drift estimations/corrections on calibrated data products and flagging related to sensors that fall outside the policy for calibration frequency, this had not been implemented at the time of COVID impacts. 
The following sites had annual refreshes canceled in 2020 and will likely go up to two years of deployment for their sensors:
BLWA (due May 2020)
TOMB (due May 2020)
BLUE (due Sept 2020)
       Date Range: 2020-03-23 to 2021-06-01
       Location(s) Affected: ALL
Resolution Date: 
Resolution: 
Issue Date: 2021-02-23
Issue: Following the planned seasonal removal of the buoy sensors, data processing continued to run producing files containing only flags. The files containing only flags have been published for the months of 11/2020 and 12/2020.
       Date Range: 2020-11-01 to 2020-12-31
       Location(s) Affected: PRPO (HOR.VER: 103.100); PRLA (HOR.VER: 103.100); LIRO (HOR.VER: 103.100); CRAM (HOR.VER: 103.100)
Resolution Date: 
Resolution: 
Issue Date: 2021-10-13
Issue: Sensor frozen in ice
       Date Range: 2017-12-07 to 2018-02-08
       Location(s) Affected: COMO
       Date Range: 2020-01-31 to 2020-02-14
       Location(s) Affected: COMO
       Date Range: 2020-12-08 to 2021-03-28
       Location(s) Affected: COMO
Resolution Date: 2021-10-13
Resolution: 
Issue Date: 2021-07-26
Issue: Wiper broken and sensor became fouled.
       Date Range: 2021-06-30 to 2021-07-14
       Location(s) Affected: BIGC
Resolution Date: 2021-07-26
Resolution: Manually cleaned and replacement with working wiper requested.
Issue Date: 2021-06-03
Issue: Sensors were removed from the stream as part of error diagnostic.
       Date Range: 2021-05-13 to 2021-05-24
       Location(s) Affected: ARIK
Resolution Date: 2021-06-03
Resolution: Data flagged.
Issue Date: 2021-06-01
Issue: Power failure during attempted calibration resulted in bad data.
       Date Range: 2021-05-18 to 2021-06-22
       Location(s) Affected: REDB
Resolution Date: 2021-06-01
Resolution: Bad data flagged. new calibration performed.
Issue Date: 2021-05-20
Issue: Light counts >65k. Lamp saturating detector.
       Date Range: 2021-03-25 to 2021-04-03
       Location(s) Affected: CUPE (102.100)
Resolution Date: 2021-05-20
Resolution: New SUNA installed. Affected data flagged.
Issue Date: 2020-01-02
Issue: Sensor buried.
       Date Range: 2019-09-27 to 2019-10-10
       Location(s) Affected: CUPE (HOR.VER: 102.100)
       Date Range: 2020-06-12 to 2020-09-11
       Location(s) Affected: ARIK
Resolution Date: 2021-03-10
Resolution: Sensor unburied and data flagged.
Issue Date: 2021-03-10
Issue: Persistent negative values.  Bad sensor or bad calibration.
       Date Range: 2020-08-29 to 2020-11-11
       Location(s) Affected: MCRA
       Date Range: 2020-12-02 to 2021-02-02
       Location(s) Affected: MCRA
Resolution Date: 2021-03-10
Resolution: Sensor replaced and data flagged.
Issue Date: 2021-03-10
Issue: Aging SUNA lamp caused drift and high measurement variability.
       Date Range: 2020-12-16 to 2021-02-17
       Location(s) Affected: ARIK
Resolution Date: 2021-03-10
Resolution: SUNA replaced and data flagged.
Issue Date: 2021-03-10
Issue: Persistent negative values.  Bad sensor or bad calibration.
       Date Range: 2021-06-17 to 2021-06-26
       Location(s) Affected: MART (HOR:112)
Resolution Date: 2021-03-10
Resolution: Sensor replaced and data flagged.
Issue Date: 2021-03-03
Issue: SUNA not cleaned or calibrated for extended period of time due to site restrictions. Data drifted downward.
       Date Range: 2020-10-30 to 2021-02-16
       Location(s) Affected: TECR
Resolution Date: 2021-03-03
Resolution: Cleaned and calibrated when site access allowed.  Data flagged.
Issue Date: 2021-03-29
Issue: High flow event dislodged sensor infrastructure.
       Date Range: 2021-01-13 to 2021-01-14
       Location(s) Affected: MART (HOR.VER: 102.100)
Resolution Date: 2021-01-14
Resolution: Sensor removed from stream.
Issue Date: 2020-06-19
Issue: Sensor detached from infrastructure
       Date Range: 2020-05-31 to 2020-06-17
       Location(s) Affected: BLDE (HOR.VER: 102.100)
Resolution Date: 2020-10-19
Resolution: SUNA reinstalled.
Issue Date: 2020-10-16
Issue: SUNA nitrate sensor malfunction.
       Date Range: 2018-11-17 to 2019-02-01
       Location(s) Affected: KING (102.100)
Resolution Date: 2020-10-16
Resolution: SUNA instrument replaced.
Issue Date: 2020-10-16
Issue: SUNA wiper malfunction caused obstruction likely influencing sensor optics.
       Date Range: 2019-01-01 to 2019-03-05
       Location(s) Affected: ARIK (102.100)
Resolution Date: 2020-10-16
Resolution: SUNA instrument replaced.
Issue Date: 2020-06-10
Issue: All data were reprocessed with the most recent algorithms, quality control thresholds, and/or other metadata to improve overall data coverage and quality. Notes have been added to the logs of previously identified issues that have been corrected.
       Date Range: 2013-01-01 to 2020-06-10
       Location(s) Affected: All
Resolution Date: 2020-06-10
Resolution: 
Issue Date: 2020-02-03
Issue: SUNA lamp malfunction prevented appropriate reference spectra updates.
       Date Range: 2018-11-11 to 2018-12-06
       Location(s) Affected: BARC (HOR.VER: 103.100)
Resolution Date: 2020-02-03
Resolution: Manual flagging applied
Issue Date: 2019-12-31
Issue: SUNA was not calibrated for extended period
       Date Range: 2017-02-01 to 2018-01-24
       Location(s) Affected: SUGG (HOR.VER: 103.100)
Resolution Date: 2019-12-31
Resolution: Field staff began calibrating SUNA
Issue Date: 2019-12-17
Issue: insufficient transmittance due to high turbidity
       Date Range: 2019-11-29 to 2019-11-30
       Location(s) Affected: SYCA (HOR.VER: 102.100)
Resolution Date: 2019-12-17
Resolution: Flood waters lowered
Issue Date: 2019-12-19
Issue: SUNA not calibrated for extended period
       Date Range: 2019-11-04 to 2019-11-27
       Location(s) Affected: REDB (HOR.VER: 102.100)
Resolution Date: 2019-11-27
Resolution: Power lost to site
Issue Date: 2019-11-20
Issue: Broken wiper resulted in excessive biofouling.
       Date Range: 2019-05-28 to 2019-09-30
       Location(s) Affected: BLUE (HOR.VER: 112.100)
       Date Range: 2019-06-03 to 2019-07-31
       Location(s) Affected: LECO (HOR.VER: 102.100)
       Date Range: 2019-09-09 to 2019-09-26
       Location(s) Affected: LEWI (HOR.VER: 102.100)
Resolution Date: 2019-11-20
Resolution: SUNA replaced.
Issue Date: 2019-11-14
Issue: Variability in SUNA logging configurations coupled with inappropriate processing algorithms caused errors in data averaging.
       Date Range: 2018-01-01 to 2019-10-25
       Location(s) Affected: ARIK (HOR.VER:102.100), BARC (HOR.VER:103.100 ),COMO (HOR.VER: 102.100),MAYF (HOR.VER: 102.100), MCDI (HOR.VER: 102.100), MCRA (HOR.VER: 102.100), POSE (HOR.VER: 102.100), PRIN (HOR.VER: 102.100), PRLA (HOR.VER: 103.100), PRPO (HOR.VER: 103.100), WLOU (HOR.VER: 102.100), WALK (HOR.VER: 102.100), SYCA (HOR.VER: 102.100)
       Date Range: 2018-01-01 to 2019-12-31
       Location(s) Affected: SUGG (HOR.VER: 103.100)
       Date Range: 2018-05-17 to 2019-10-25
       Location(s) Affected: REDB (HOR.VER: 102.100)
       Date Range: 2018-06-06 to 2019-10-25
       Location(s) Affected: CARI (HOR.VER:102.100)
       Date Range: 2018-06-14 to 2019-10-25
       Location(s) Affected: BLWA (HOR.VER: 103.100),TOMB (HOR.VER: 103.100)
       Date Range: 2018-09-02 to 2019-10-25
       Location(s) Affected: BLUE (HOR.VER: 102.100)
       Date Range: 2018-09-24 to 2019-10-25
       Location(s) Affected: BIGC (HOR.VER: 102.100), BLDE (HOR.VER:102.100)
       Date Range: 2018-10-01 to 2018-12-31
       Location(s) Affected: TECR (HOR.VER: 102.100)
       Date Range: 2019-01-01 to 2019-10-25
       Location(s) Affected: CRAM (HOR.VER: 103.100), CUPE (HOR.VER: 102.100), FLNT  (HOR.VER: 103.100), GUIL (HOR.VER: 102.100), HOPB (HOR.VER: 102.100 & 112.100), LECO (HOR.VER: 102.100 & 112.100), LEWI (HOR.VER: 102.100), LIRO (HOR.VER: 103.100),TOOK (HOR.VER: 103.100), TECR (HOR.VER: 102.100)
       Date Range: 2019-01-01 to 2019-12-10
       Location(s) Affected: MART (HOR.VER: 102.100)
Resolution Date: 2019-11-14
Resolution: Configurations and algorithms were updated and data was reprocessed.
Issue Date: 2020-03-12
Issue: Buoy moved significantly down river while streaming data.
       Date Range: 2019-11-01 to 2019-11-03
       Location(s) Affected: TOMB (HOR.VER: 103.100)
Resolution Date: 2019-11-03
Resolution: Buoy stopped transmitting data
Issue Date: 2019-10-11
Issue: reference spectrum max light count > 55,000
       Date Range: 2019-09-30 to 2019-10-08
       Location(s) Affected: BLUE (HOR.VER: 112.100
Resolution Date: 2019-10-08
Resolution: Sensor removed, manual flagging added
Issue Date: 2019-08-26
Issue: Sensor possibly exposed to air
       Date Range: 2019-08-11 to 2019-08-23
       Location(s) Affected: PRIN (HOR.VER: 102.100)
       Date Range: 2019-08-24 to 2019-08-25
       Location(s) Affected: BLUE (HOR.VER: 112.100)
Resolution Date: 2019-08-25
Resolution: Sensor returned to water
Issue Date: 2019-06-18
Issue: SUNA lamp malfunctioning
       Date Range: 2019-04-01 to 2019-04-28
       Location(s) Affected: MCDI (HOR.VER: 102.100)
Resolution Date: 2019-05-04
Resolution: SUNA removed,  manual flagging added.
Issue Date: 2019-05-09
Issue: Incorrect calibration resulted in faulty data
       Date Range: 2019-03-22 to 2019-05-01
       Location(s) Affected: WALK (HOR.VER: 102.100)
       Date Range: 2019-06-06 to 2020-07-03
       Location(s) Affected: BARC (HOR.VER: 103.100)
       Date Range: 2020-01-09 to 2020-01-21
       Location(s) Affected: WALK (HOR.VER: 102.100)
       Date Range: 2020-02-04 to 2020-03-03
       Location(s) Affected: TECR (HOR.VER: 102.100)
Resolution Date: 2019-05-01
Resolution: New calibration performed.  Manual flagging added.
Issue Date: 2019-06-17
Issue: SUNA not cleaned or calibrated for extended period
       Date Range: 2019-03-05 to 2019-03-18
       Location(s) Affected: REDB (HOR.VER: 102.100)
Resolution Date: 2019-03-18
Resolution: SUNA calibrated, manual flagging applied.
Issue Date: 2019-06-19
Issue: SUNA not calibrated within 1 month
       Date Range: 2019-02-07 to 2019-03-04
       Location(s) Affected: GUIL (HOR.VER: 102.100)
Resolution Date: 2019-03-04
Resolution: SUNA replaced, manual flagging applied
Issue Date: 2019-02-19
Issue: Processing failures resulted in poor data product coverage for some sites and time periods.
       Date Range: 2018-01-01 to 2018-10-31
       Location(s) Affected: All locations.
Resolution Date: 2019-02-19
Resolution: Data reprocessed to improve data product coverage.
Issue Date: 2019-06-17
Issue: Sensor configured incorrectly
       Date Range: 2018-05-01 to 2019-01-28
       Location(s) Affected: BIGC (HOR.VER: 102.100)
Resolution Date: 2019-01-28
Resolution: Sensor replaced
Issue Date: 2018-12-03
Issue: Water level receded and SUNA nitrate sensor became at least partially exposed.
       Date Range: 2017-07-01 to 2017-11-01
       Location(s) Affected: POSE (HOR.VER: 102.100)
       Date Range: 2018-10-10 to 2018-11-01
       Location(s) Affected: KING (HOR.VER: 102.100)
       Date Range: 2020-09-11 to 2020-11-02
       Location(s) Affected: ARIK (HOR.VER: 102.100)
Resolution Date: 2018-12-03
Resolution: Manual flagging applied.
Issue Date: 2018-08-30
Issue: SUNA drifted outside of accuracy threshold
       Date Range: 2018-02-25 to 2018-04-11
       Location(s) Affected: BARC
Resolution Date: 2018-08-30
Resolution: Manual flagging applied. Sensor offline while site awaits repair.
Issue Date: 2018-04-11
Issue: SUNA removed from KING due to low water levels
       Date Range: 2017-09-19 to 2018-04-11
       Location(s) Affected: KING(102.100)
Resolution Date: 2018-04-11
Resolution: Sensor offline until reinstallation
Issue Date: 2018-04-05
Issue: S2 infrastructure was damaged due to flooding.
       Date Range: 2018-03-27 to 2018-03-28
       Location(s) Affected: CUPE (102.100)
       Date Range: 2018-10-13 to 2018-10-18
       Location(s) Affected: PRIN (HOR.VER: 102.100)
Resolution Date: 2018-04-05
Resolution: Manual flagging applied. Sensor offline while site awaits repair.
Issue Date: 2018-03-27
Issue: Infrastructure damage to S2 from high flow event and calibration not verified prior to site repair.
       Date Range: 2018-02-21 to 2018-03-22
       Location(s) Affected: PRIN (102.100)
Resolution Date: 2018-03-22
Resolution: Manual flagging applied. Sensor offline while site awaits repair.
Issue Date: 2018-01-18
Issue: SUNA removed from the water and streaming from the bank.
       Date Range: 2017-12-12 to 2017-12-28
       Location(s) Affected: MCRA
Resolution Date: 2017-12-28
Resolution: SUNA returned to water.
Issue Date: 2018-02-05
Issue: S2 submerged and sensor position altered due to infrastructure damage from high flow event. Data are still usable.
       Date Range: 2017-10-30 to 2017-11-07
       Location(s) Affected: HOPB
Resolution Date: 2017-11-07
Resolution: Sensor offline while site awaiting repairs.
Issue Date: 2020-11-20
Issue: SUNA only calibrated annually.  No field calibrations
       Date Range: 2010-01-01 to 2017-07-01
       Location(s) Affected: All Sites
Resolution Date: 2017-07-01
Resolution: Calibration procedure created
ADDITIONAL INFORMATION
----------------------
NEON DATA POLICY AND CITATION GUIDELINES
----------------------------------------
A citation statement is available in this data product's detail page at https://data.neonscience.org/data-products/DP1.20033.001. Please visit https://www.neonscience.org/data-policy for more information about NEON's data policy and citation guidelines.
DATA QUALITY AND VERSIONING
---------------------------
NEON data are initially published with a status of Provisional, in which updates to data and/or processing algorithms will occur on an as-needed basis, and query reproducibility cannot be guaranteed. Once data are published as part of a Data Release, they are no longer provisional, and are associated with a stable DOI. 
To learn more about provisional versus released data, please visit https://www.neonscience.org/data-revisions-releases.
