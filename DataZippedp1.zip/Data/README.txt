Read me file for data for hydrological data analysis project folder
Author: Lara Munro
Date: December 2021

Folder contents:
- chemGrab: chemical properties of surface water (NEON DP1.20093.001 – 2 week frequency)
- discharge: continuous discharge (NEON DP4.00130.001 – 1 minute frequency)
- sensorNO3: nitrate in surface water from sensors (NEON DP1.20033.001– 15 minute frequency)

Each folder contains the main data file for each measurment (named after each site), 
a README file from NEON and a variables files from NEON.
The chemical properties of surface water files have been manipulated in R for readability.
The manipulations are removing all flagged values and reshaping the table so that each analyte 
is represented in an individual column. Error ranges on these values are not included and raw 
data files should be consulted for this.


